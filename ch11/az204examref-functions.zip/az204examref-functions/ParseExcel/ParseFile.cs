﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using az204examref_functions;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace AZ204ExamRefSimpleFunctionApp.ParseExcel
{
    public class ParseFile
    {
        public static List<SampleDataItem> ParseDataFile(MemoryStream fileStreamInMemory)
        {
            fileStreamInMemory.Position = 0;

            var sampleData = new List<SampleDataItem>();

            string columnRef;

            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(fileStreamInMemory, false))
            {
                var workbookPart = spreadsheetDocument.WorkbookPart;
                if (workbookPart == null) throw new Exception("invalid excel file | workbook");
                var worksheetPart = workbookPart?.WorksheetParts.First();
                if (worksheetPart == null) throw new Exception("invalid excel file | worksheet");
                var sstpart = workbookPart?.GetPartsOfType<SharedStringTablePart>().First();
                if (sstpart == null) throw new Exception("invalid excel file | sheet table");
                var sst = sstpart?.SharedStringTable;
                if (sst == null) throw new Exception("invalid excel file | shared string table");
                var sheetData = worksheetPart?.Worksheet.Elements<SheetData>().First();
                if (sheetData == null) throw new Exception("invalid excel file | sheet data");
                foreach (Row r in sheetData.Elements<Row>())
                {
                    var nextRowIndex = r.RowIndex ?? 0;
                    if (nextRowIndex == 1)
                    {
                        //skip columns row
                        continue;
                    }

                    var sdi = new SampleDataItem();

                    foreach (Cell c in r.Elements<Cell>())
                    {
                        if (c == null) continue;
                        columnRef = c.CellReference?.Value?.Substring(0, 1) ?? "";

                        string dataString = c.CellValue?.Text ?? string.Empty;

                        if ((c.DataType != null) && (c.DataType == CellValues.SharedString))
                        {
                            var isIndex = int.TryParse(c?.CellValue?.Text, out int ssid);
                            if (!isIndex) continue;
                            dataString = sst.ChildElements[ssid].InnerText;
                        }

                        switch (columnRef)
                        {
                            case "A":
                                //ID
                                var isId = int.TryParse(dataString, out int id);
                                if (isId && id > 0)
                                {
                                    sdi.Id = id;
                                }
                                break;
                            case "B":
                                //Title
                                sdi.Title = dataString;
                                break;
                            case "C":
                                //Rating
                                sdi.Rating = dataString;
                                break;
                            case "D":
                                //Type
                                sdi.Type = dataString;
                                break;
                        }
                    }

                    if (sdi.Id > 0)
                    {
                        sampleData.Add(sdi);
                    }
                }
            }

            return sampleData;
        }
    }
}
