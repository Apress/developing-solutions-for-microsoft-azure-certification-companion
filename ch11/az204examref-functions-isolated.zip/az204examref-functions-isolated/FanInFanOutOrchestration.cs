using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.DurableTask;
using Microsoft.DurableTask.Client;
using Microsoft.Extensions.Logging;
using System.Threading;

namespace az204examref_functions_isolated
{
    /*
    public static class FanInFanOutOrchestration
    {


        [Function(nameof(FanInFanOutOrchestration))]
        public static async Task<int> RunOrchestrator(
            [OrchestrationTrigger] TaskOrchestrationContext context)
        {
            var workBatch = await context.CallActivityAsync<int>("FirstFunction", 0);

            ILogger log = context.CreateReplaySafeLogger(nameof(FanInFanOutOrchestration));
            log.LogInformation($"Starting the fan out/in orchestration with {workBatch} workload function calls");

            //use parallel tasks to fan out and call n operations simultaneously
            var parallelTasks = new List<Task<int>>();

            for (int i = 1; i <= workBatch; i++)
            {
                Task<int> nextWorker = context.CallActivityAsync<int>("WorkloadFunction", i);
                parallelTasks.Add(nextWorker);
            }

            log.LogInformation("Parallel Tasks completed!");
            // Aggregate all N outputs and send the result to Final Function.

            await Task.WhenAll(parallelTasks);

            //get the total from all execution calculations:
            var total = parallelTasks.Sum(w => w.Result);

            log.LogInformation($"Total sent to final function: {total}");
            await context.CallActivityAsync("FinalFunction", total);

            return total;
        }

        [Function(nameof(FirstFunction))]
        public static int FirstFunction([ActivityTrigger] int starter, FunctionContext executionContext)
        {
            ILogger log = executionContext.GetLogger(nameof(FirstFunction));

            //do some setup work here, other startup function tasks
            var numberOfWorkersToProcess = starter;
            try
            {
                bool success = int.TryParse(Environment.GetEnvironmentVariable("NumberOfWorkerFunctions")
                                                , out numberOfWorkersToProcess);
            }
            catch (Exception ex)
            {
                log.LogError("The environment variable NumberOfWorkerFunctions is unset!", ex);
            }

            log.LogInformation($"Current number of workers {numberOfWorkersToProcess}.");
            return numberOfWorkersToProcess;
        }


        [Function(nameof(WorkloadFunction))]
        public static int WorkloadFunction([ActivityTrigger] int nextWorkload, FunctionContext executionContext)
        {
            ILogger log = executionContext.GetLogger(nameof(WorkloadFunction));

            //do the work
            var computed = nextWorkload * 2;
            log.LogInformation($"Current detail {nextWorkload} | Computed: {computed}.");
            return computed;
        }

        [Function(nameof(FinalFunction))]
        public static int FinalFunction([ActivityTrigger] int total, FunctionContext executionContext)
        {
            ILogger log = executionContext.GetLogger(nameof(FinalFunction));

            //complete the work here
            log.LogInformation($"Final Function [value]: {total}.");
            return total;
        }

        [Function("FanInFanOutOrchestration_HttpStart")]
        public static async Task<HttpResponseData> HttpStart(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequestData req,
            [DurableClient] DurableTaskClient client,
            FunctionContext executionContext)
        {
            ILogger logger = executionContext.GetLogger("FanInFanOutOrchestration_HttpStart");

            // Function input comes from the request content.
            string instanceId = await client.ScheduleNewOrchestrationInstanceAsync(
                nameof(FanInFanOutOrchestration));

            logger.LogInformation("Started orchestration with ID = '{instanceId}'.", instanceId);

            // Returns an HTTP 202 response with an instance management payload.
            // See https://learn.microsoft.com/azure/azure-functions/durable/durable-functions-http-api#start-orchestration
            return client.CreateCheckStatusResponse(req, instanceId);
        }
    }
    */
}
