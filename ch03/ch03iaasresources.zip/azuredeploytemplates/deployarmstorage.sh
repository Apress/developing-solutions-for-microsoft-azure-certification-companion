rg=your-group-name-here
az deployment group create -g $rg --template-file azuredeploy.json
