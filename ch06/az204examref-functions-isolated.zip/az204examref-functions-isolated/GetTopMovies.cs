using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace az204examref_functions_isolated
{
    public class GetTopMovies
    {
        private readonly ILogger _logger;

        public GetTopMovies(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<GetTopMovies>();
        }

        [Function("GetTopMovies")]
        public HttpResponseData Run([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            var movieData = TopMovies();

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "text/plain; charset=utf-8");

            response.WriteString(JsonConvert.SerializeObject(movieData));

            return response;
        }

        private static List<SampleDataItem> TopMovies()
        {
            return new List<SampleDataItem>()
            {
                new SampleDataItem() { Id = 1, Rating = "R", Title = "The Shawshank Redemption", Type = "Movie"},
                new SampleDataItem() { Id = 2, Rating = "R", Title = "The Godfather", Type = "Movie"},
                new SampleDataItem() { Id = 3, Rating = "PG-13", Title = "The Dark Knight", Type = "Movie"},
                new SampleDataItem() { Id = 4, Rating = "NR", Title = "12 Angry Men", Type = "Movie"},
                new SampleDataItem() { Id = 5, Rating = "R", Title = "Schindler's List", Type = "Movie"},
                new SampleDataItem() { Id = 6, Rating = "PG-13", Title = "The Lord of the Rings: The Return of the King", Type = "Movie"},
                new SampleDataItem() { Id = 7, Rating = "R", Title = "Pulp Fiction", Type = "Movie"},
            };
        }
    }
}
