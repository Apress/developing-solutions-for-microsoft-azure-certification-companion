// Default URL for triggering event grid function in the local environment.
// http://localhost:7071/runtime/webhooks/EventGrid?functionName={functionname}
using az204examref_functions_isolated.ParseExcel;
using Azure.Messaging.EventGrid.SystemEvents;
using Azure.Storage.Blobs;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace az204examref_functions_isolated
{
    /*
    public class ProcessExcelToCosmosWithBindings
    {

        private readonly ILogger _logger;

        public ProcessExcelToCosmosWithBindings(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<ProcessExcelToCosmosWithBindings>();
        }

        [Function("ProcessExcelToCosmosWithBindings")]
        [CosmosDBOutput("SampleDataItems", "ItemsFromIsolatedBindings", Connection = "myCosmosConnection", CreateIfNotExists = true)]
        public async Task<object> Run([BlobTrigger("uploads/{name}", Connection = "myStorageConnection")] string blobData, string name,
                                        [BlobInput("uploads/{name}", Connection = "myStorageConnection")] BlobClient blobClient, 
                                        FunctionContext context)
        {
            _logger.LogInformation(name);
            if (blobClient is null)
            {
                _logger.LogCritical("BlobClient is null");
                throw new Exception("BlobClient is null");
            }
            _logger.LogInformation(blobClient.Uri.ToString());
            List<CosmosSampleDataItem> sampleDataItems = new List<CosmosSampleDataItem>();

            try 
            {
                _logger.LogInformation("Starting to download blob..");
                using (var ms = new MemoryStream())
                {
                    blobClient.DownloadTo(ms);
                    _logger.LogInformation("Blob Donwloaded - Being Parsing file..");
                    var parseResults = ParseFile.ParseDataFile(ms);
                    foreach (var pr in parseResults)
                    {
                        _logger.LogInformation($"Adding {pr.Title} to cosmos db output documents");
                        sampleDataItems.Add(pr);
                    }
                    _logger.LogInformation("Parsing complete");
                }
            }
            catch (Exception ex)
            {
                //had a lot of problems in the above sections with the storage interaction, so added this to help debug
                _logger.LogCritical(ex.Message);
                throw;
            }
            
            //Note: This seems to be smart enought to do upsert based on `id & Title` automatically!
            _logger.LogInformation($"Returning sampleDataItems with {sampleDataItems.Count} items");
            return sampleDataItems;
        }
    }
    */
}
