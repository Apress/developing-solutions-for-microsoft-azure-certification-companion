using az204examref_functions_isolated.ParseExcel;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Cosmos;

namespace az204examref_functions_isolated
{
    /** 
     * Requires:
     * - myStorageConnection: storage account connection string
     *      - container named 'uploads' in storage account
     * - myCosmosConnection: cosmos db connection string
     *      - Database named 'SampleDataItems' with container named 'ItemsFromIsolated'
     **/
    public class ProcessExcelToCosmos
    {

        [Function("ProcessExcelToCosmos")]
        public async Task Run([BlobTrigger("uploads/{name}", Connection = "myStorageConnection")] string blobData, string name, string blobTrigger, string Uri
                    , FunctionContext context)
        {
            var _logger = context.GetLogger("ProcessExcelToCosmos");
            _logger.LogInformation($"C# Blob trigger function Processed blob\n Name: {name} \n FullPath : {Uri}");

            var cnstr = Environment.GetEnvironmentVariable("myStorageConnection");
            var blobStorageClient = new BlobServiceClient(cnstr);
            var containerClient = blobStorageClient.GetBlobContainerClient("uploads");
            var blobClient = containerClient.GetBlobClient(name);

            var cosmosClient = new CosmosClient(Environment.GetEnvironmentVariable("myCosmosConnection"));
            var database = cosmosClient.GetDatabase("SampleDataItems");
            var container = database.GetContainer("ItemsFromIsolated");

            List<CosmosSampleDataItem> sampleDataItems = new List<CosmosSampleDataItem>();
            using (var downloadFileStream = new MemoryStream())
            {
                blobClient.DownloadTo(downloadFileStream);
                _logger.LogInformation("Parsing file..");
                sampleDataItems = ParseFile.ParseDataFile(downloadFileStream);

                foreach (var sdi in sampleDataItems)
                {
                    _logger.LogInformation($"Found {sdi.Title} for cosmos db output documents");
                    await container.UpsertItemAsync(sdi);
                }
            }
        }
    }
}
