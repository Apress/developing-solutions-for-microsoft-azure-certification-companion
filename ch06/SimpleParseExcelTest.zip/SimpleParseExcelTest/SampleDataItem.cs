﻿namespace SimpleParseExcelTest
{
    public class SampleDataItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Rating { get; set; }
        public string Type { get; set; }
    }
}
