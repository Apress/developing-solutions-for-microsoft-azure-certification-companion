﻿namespace SimpleParseExcelTest
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Now Reading Excel data");

            byte[] data;
            var f = "SampleData.xlsx";
            long numBytes = new FileInfo(f).Length;

            FileStream fs = new FileStream(f,
                                           FileMode.Open,
                                           FileAccess.Read);
           
            using (var br = new BinaryReader(fs))
            {
                data = br.ReadBytes((int)numBytes);
            }
            using (var ms = new MemoryStream(data))
            {
                var x = ParseExcel.ParseDataFile(ms);
                foreach (var sdi in x)
                {
                    Console.WriteLine($"{sdi.Title}");
                }
            }

            Console.WriteLine("Program Completed...");
        }
    }
}