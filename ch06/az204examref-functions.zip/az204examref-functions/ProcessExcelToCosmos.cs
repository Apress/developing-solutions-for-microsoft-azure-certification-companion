// Default URL for triggering event grid function in the local environment.
// http://localhost:7071/runtime/webhooks/EventGrid?functionName={functionname}
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.EventGrid;
using Microsoft.Extensions.Logging;
using Azure.Messaging.EventGrid;
using System.Threading.Tasks;
using System.IO;
using AZ204ExamRefSimpleFunctionApp.ParseExcel;

namespace az204examref_functions
{
    /**
     * Requires: Configuration Settings:
     *  - myStorageConnection : the connection string for the storage account to read the file
     *  - myCosmosConnection : the connection string for the cosmos db account to write the data to
     *  - cosmos db named SampleDataItems with a collection named Items in the cosmos db account
    **/
    public static class ProcessExcelToCosmos
    {
        /*
        [FunctionName("ProcessExcelToCosmos")]
        public static async Task Run([EventGridTrigger] EventGridEvent eventGridEvent,
                [Blob(blobPath: "{data.url}", access: FileAccess.Read,
                    Connection = "myStorageConnection")] Stream fileToProcess,
                [CosmosDB(
                    databaseName: "SampleDataItems",
                    collectionName: "Items",
                    ConnectionStringSetting = "myCosmosConnection",
                    CreateIfNotExists = true)]
                    IAsyncCollector<SampleDataItem> sampleDataItemDocuments,
                ILogger log)
        {
            log.LogInformation(eventGridEvent.Data.ToString());
            log.LogInformation($"FileInfo: {fileToProcess.Length}");

            // Convert the incoming image stream to a byte array.
            byte[] data;

            using (var br = new BinaryReader(fileToProcess))
            {
                data = br.ReadBytes((int)fileToProcess.Length);
            }

            using (var ms = new MemoryStream(data))
            {
                log.LogInformation("Parsing file..");
                var parseResults = ParseFile.ParseDataFile(ms);
                foreach (var pr in parseResults)
                {
                    //TODO: Check for duplicates and "Upsert" instead of "Add"
                    log.LogInformation($"Adding {pr.Title} to cosmos db output documents");
                    await sampleDataItemDocuments.AddAsync(pr);
                }
            }
        }
        */
    }
}
