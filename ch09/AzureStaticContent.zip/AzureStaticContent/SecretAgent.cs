﻿namespace AzureStaticContent
{
    public class SecretAgent
    {
        public string AgentId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }

        public SecretAgent()
        {
            //blank by design
        }

        public SecretAgent(string agentId, string name, int age)
        {
            AgentId = agentId;
            Name = name;
            Age = age;
        }

        public override string ToString()
        {
            return $"ID: {AgentId} | Name: {Name} | Age:{Age}";
        }
    }
}
