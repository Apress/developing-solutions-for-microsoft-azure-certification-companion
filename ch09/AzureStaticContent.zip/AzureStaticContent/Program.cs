﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using StackExchange.Redis;

namespace AzureStaticContent
{
    public class Program
    {
        private static IConfigurationRoot _configuration;

        public static async Task Main(string[] args)
        {
            BuildOptions();
            Console.WriteLine("Azure Static Content");

            await InteractWithRedis();
        }

        private static void BuildOptions()
        {
            _configuration = ConfigurationBuilderSingleton.ConfigurationRoot;
        }

        private static Lazy<ConnectionMultiplexer> redisConnection = new Lazy<ConnectionMultiplexer>(() =>
        {
            var redisConnectionString = _configuration["AzureSettings:RedisCache:ConnectionString"];
            return ConnectionMultiplexer.Connect(redisConnectionString);
        });

        private static async Task InteractWithRedis()
        {
            //get the database [IDatabase object]
            var db = redisConnection.Value.GetDatabase();

            // Simple PING command
            var cacheCommand = "PING";
            Console.WriteLine("\nCache command : " + cacheCommand);
            Console.WriteLine("Cache response : " + db.Execute(cacheCommand).ToString());

            //set A key/value in cache
            var key = "Message";
            var msg = "Hello! The cache is working from a .NET console app!";
            Console.WriteLine("Cache response : " + db.StringSet(key, msg).ToString());

            //get the value by key from cache
            var msgValue = db.StringGet(key);
            Console.WriteLine($"Message Retrieved: {msgValue}");

            //cache serialized JSON
            SecretAgent agentBond =  new SecretAgent("007", "James Bond", 36);
            db.StringSet("a007", JsonConvert.SerializeObject(agentBond));

            Console.WriteLine("Agent Info:");
            var cachedAgentBond = JsonConvert.DeserializeObject<SecretAgent>(db.StringGet("a007"));
            Console.WriteLine(cachedAgentBond);
            Console.WriteLine($"Name: {cachedAgentBond.Name}");

            //get the client information
            var clientList = db.Execute("CLIENT", "LIST").ToString().Replace("id=", "|id=");
            Console.WriteLine($"Cache response : \n{clientList}");
            var clients = clientList.Split("|");
            foreach (var client in clients)
            {
                if (string.IsNullOrWhiteSpace(client)) continue;
                Console.WriteLine("Next Client:");
                Console.WriteLine(client.Replace("|id=", "id="));
            }

            

            return;
        }
    }
}
